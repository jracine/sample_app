class ::Object #:nodoc:
  def meta_class
    class << self; self end
  end
end

