class NilClass #:nodoc:
  def to_query_string
    nil
  end
end
