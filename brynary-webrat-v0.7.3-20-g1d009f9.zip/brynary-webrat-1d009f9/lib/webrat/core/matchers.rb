require "webrat/core/matchers/have_xpath"
require "webrat/core/matchers/have_selector"
require "webrat/core/matchers/have_tag"
require "webrat/core/matchers/have_content"
