require "webrat/selenium/matchers/have_xpath"
require "webrat/selenium/matchers/have_selector"
# require "webrat/selenium/matchers/have_tag"
require "webrat/selenium/matchers/have_content"
