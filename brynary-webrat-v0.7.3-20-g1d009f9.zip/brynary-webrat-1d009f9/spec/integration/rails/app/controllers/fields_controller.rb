class FieldsController < ApplicationController
  def show
  end
end
